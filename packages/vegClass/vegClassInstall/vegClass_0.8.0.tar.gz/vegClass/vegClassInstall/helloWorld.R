################################################################################
#helloWorld.R
#
#Basic R script referenced in vegClass R package documentation.
################################################################################

cat("Hello World", "\n")
cat("Welcome to R.")

